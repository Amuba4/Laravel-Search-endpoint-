<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Items List</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
    <style>
        table th {
            cursor: pointer;
        }
    </style>
</head>
<body>

    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Items App</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
    </nav>

    <div class="container mt-5">
        <h1>Items List</h1>

        <!-- Filter Form -->
        <!-- Filter Form -->
<form id="filterForm" method="GET" action="{{ route('items.index') }}" class="mb-3">
    <div class="row">
        <div class="col-md-3">
            <input type="text" name="category" id="category" class="form-control" placeholder="Category" value="{{ request('category') }}">
        </div>
        <div class="col-md-3">
            <input type="number" name="price" id="price" class="form-control" placeholder="Price" value="{{ request('price') }}">
        </div>
        <div class="col-md-1">
            <button type="submit" class="btn btn-primary">Filter</button>
        </div>
        <div class="col-md-0">
            <button type="button" id="clearButton" class="btn btn-secondary">Clear</button>
        </div>
        <div class="col-md-2">
            <!-- Export Button -->
            <button type="button" id="exportButton" class="btn btn-success">Export to CSV</button>
        </div>
    </div>
</form>


        <!-- Items Table -->
        <table id="itemsTable" class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($items as $item)
                <tr>
                    <td>{{ $item->id }}</td>
                    <td>{{ $item->name }}</td>
                    <td>{{ $item->category }}</td>
                    <td>{{ $item->price }}</td>
                    <td>{{ $item->status }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>

        <!-- Pagination Info -->
        <div class="d-flex justify-content-between">
            <div>
                Showing {{ $items->firstItem() }} to {{ $items->lastItem() }} of {{ $items->total() }} items
            </div>
            <div>
                {{ $items->appends(request()->query())->links('pagination::bootstrap-4') }}
            </div>
        </div>

    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            // Initialize DataTable
            var table = $('#itemsTable').DataTable({
                "paging": false,   // Disable paging for DataTables (we'll use Laravel's pagination)
                "searching": true, // Enable search
                "ordering": true,  // Enable sorting
                "info": false,     // Disable DataTables info text
                "order": []        // Initial sorting (leave empty for no default sort)
            });

            // Export button click handler
            $('#exportButton').on('click', function() {
                // Get filter and search parameters
                var category = $('#category').val();
                var price = $('#price').val();
                var search = table.search();

                // Construct URL with query parameters
                var exportUrl = "{{ route('items.exportCsv') }}" + 
                                '?category=' + encodeURIComponent(category) +
                                '&price=' + encodeURIComponent(price) +
                                '&search=' + encodeURIComponent(search);

                // Redirect to export route with parameters
                window.location.href = exportUrl;
            });


             // Clear button click handler
        $('#clearButton').on('click', function() {
            // Clear form fields
            $('#category').val('');
            $('#price').val('');
            table.search('').draw(); // Clear DataTable search as well

            // Optionally, submit the form to reload the page without filters
            $('#filterForm').submit();
        });
        });
    </script>
</body>
</html>
